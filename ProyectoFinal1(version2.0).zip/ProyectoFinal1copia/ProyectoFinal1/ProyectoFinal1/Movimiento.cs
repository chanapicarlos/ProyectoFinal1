﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// integrantes:
// Jeicob Zurita 2-757-811
// Carlos Chanapi 5-718-1429
// Jhony Batista 8-1041-749
// Iker Perez 8-1026-2291
namespace ProyectoFinal1
{
    /// <summary>
    /// Representa un movimiento de inventario (préstamo o entrega).
    /// </summary>
    public class Movimiento
    {
        public int Id { get; set; }
        public string NombreElemento { get; set; }
        public TipoMovimiento Tipo { get; set; }
        public int Cantidad { get; set; }
        public DateTime Fecha { get; set; }

        public Movimiento() { }

        public Movimiento(string nombreElemento, TipoMovimiento tipo,
                          int cantidad, DateTime fecha)
        {
            NombreElemento = nombreElemento;
            Tipo = tipo;
            Cantidad = cantidad;
            Fecha = fecha;
        }

        /// <summary>
        /// Devuelve -1 para préstamo (resta) y 1 para entrega (suma).
        /// </summary>
        public int ObtenerSigno()
        {
            return Tipo == TipoMovimiento.Prestamo ? -1 : 1;
        }
    }
}
