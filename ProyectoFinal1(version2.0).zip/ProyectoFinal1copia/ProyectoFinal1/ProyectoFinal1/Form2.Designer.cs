﻿namespace ProyectoFinal1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.grpFiltro = new System.Windows.Forms.GroupBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.dtpFechaFiltro = new System.Windows.Forms.DateTimePicker();
            this.chkVaso = new System.Windows.Forms.CheckBox();
            this.chkEspatula = new System.Windows.Forms.CheckBox();
            this.chkTenaza = new System.Windows.Forms.CheckBox();
            this.chkTubo = new System.Windows.Forms.CheckBox();
            this.chkMatraz = new System.Windows.Forms.CheckBox();
            this.chkVidrioReloj = new System.Windows.Forms.CheckBox();
            this.chkEmbudo = new System.Windows.Forms.CheckBox();
            this.chkCilindro = new System.Windows.Forms.CheckBox();
            this.chkTodos = new System.Windows.Forms.CheckBox();
            this.dgvInventario = new System.Windows.Forms.DataGridView();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.grpFiltro.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventario)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // grpFiltro
            // 
            this.grpFiltro.Controls.Add(this.btnBuscar);
            this.grpFiltro.Controls.Add(this.dtpFechaFiltro);
            this.grpFiltro.Controls.Add(this.chkVaso);
            this.grpFiltro.Controls.Add(this.chkEspatula);
            this.grpFiltro.Controls.Add(this.chkTenaza);
            this.grpFiltro.Controls.Add(this.chkTubo);
            this.grpFiltro.Controls.Add(this.chkMatraz);
            this.grpFiltro.Controls.Add(this.chkVidrioReloj);
            this.grpFiltro.Controls.Add(this.chkEmbudo);
            this.grpFiltro.Controls.Add(this.chkCilindro);
            this.grpFiltro.Controls.Add(this.chkTodos);
            this.grpFiltro.Location = new System.Drawing.Point(12, 23);
            this.grpFiltro.Name = "grpFiltro";
            this.grpFiltro.Size = new System.Drawing.Size(450, 636);
            this.grpFiltro.TabIndex = 0;
            this.grpFiltro.TabStop = false;
            this.grpFiltro.Text = "Filtro";
            // 
            // btnBuscar
            // 
            this.btnBuscar.Location = new System.Drawing.Point(87, 520);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(244, 75);
            this.btnBuscar.TabIndex = 9;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // dtpFechaFiltro
            // 
            this.dtpFechaFiltro.Location = new System.Drawing.Point(34, 437);
            this.dtpFechaFiltro.Name = "dtpFechaFiltro";
            this.dtpFechaFiltro.Size = new System.Drawing.Size(321, 26);
            this.dtpFechaFiltro.TabIndex = 8;
            // 
            // chkVaso
            // 
            this.chkVaso.AutoSize = true;
            this.chkVaso.Location = new System.Drawing.Point(34, 338);
            this.chkVaso.Name = "chkVaso";
            this.chkVaso.Size = new System.Drawing.Size(126, 24);
            this.chkVaso.TabIndex = 7;
            this.chkVaso.Text = "vaso químico";
            this.chkVaso.UseVisualStyleBackColor = true;
            // 
            // chkEspatula
            // 
            this.chkEspatula.AutoSize = true;
            this.chkEspatula.Location = new System.Drawing.Point(34, 308);
            this.chkEspatula.Name = "chkEspatula";
            this.chkEspatula.Size = new System.Drawing.Size(98, 24);
            this.chkEspatula.TabIndex = 6;
            this.chkEspatula.Text = "Espatula";
            this.chkEspatula.UseVisualStyleBackColor = true;
            // 
            // chkTenaza
            // 
            this.chkTenaza.AutoSize = true;
            this.chkTenaza.Location = new System.Drawing.Point(34, 278);
            this.chkTenaza.Name = "chkTenaza";
            this.chkTenaza.Size = new System.Drawing.Size(88, 24);
            this.chkTenaza.TabIndex = 5;
            this.chkTenaza.Text = "Tenaza";
            this.chkTenaza.UseVisualStyleBackColor = true;
            // 
            // chkTubo
            // 
            this.chkTubo.AutoSize = true;
            this.chkTubo.Location = new System.Drawing.Point(34, 248);
            this.chkTubo.Name = "chkTubo";
            this.chkTubo.Size = new System.Drawing.Size(148, 24);
            this.chkTubo.TabIndex = 4;
            this.chkTubo.Text = " tubo de ensayo";
            this.chkTubo.UseVisualStyleBackColor = true;
            // 
            // chkMatraz
            // 
            this.chkMatraz.AutoSize = true;
            this.chkMatraz.Location = new System.Drawing.Point(34, 218);
            this.chkMatraz.Name = "chkMatraz";
            this.chkMatraz.Size = new System.Drawing.Size(84, 24);
            this.chkMatraz.TabIndex = 3;
            this.chkMatraz.Text = "Matraz";
            this.chkMatraz.UseVisualStyleBackColor = true;
            // 
            // chkVidrioReloj
            // 
            this.chkVidrioReloj.AutoSize = true;
            this.chkVidrioReloj.Location = new System.Drawing.Point(34, 188);
            this.chkVidrioReloj.Name = "chkVidrioReloj";
            this.chkVidrioReloj.Size = new System.Drawing.Size(115, 24);
            this.chkVidrioReloj.TabIndex = 2;
            this.chkVidrioReloj.Text = "Vidrio Reloj";
            this.chkVidrioReloj.UseVisualStyleBackColor = true;
            // 
            // chkEmbudo
            // 
            this.chkEmbudo.AutoSize = true;
            this.chkEmbudo.Location = new System.Drawing.Point(34, 158);
            this.chkEmbudo.Name = "chkEmbudo";
            this.chkEmbudo.Size = new System.Drawing.Size(95, 24);
            this.chkEmbudo.TabIndex = 1;
            this.chkEmbudo.Text = "Embudo";
            this.chkEmbudo.UseVisualStyleBackColor = true;
            // 
            // chkCilindro
            // 
            this.chkCilindro.AutoSize = true;
            this.chkCilindro.Location = new System.Drawing.Point(34, 128);
            this.chkCilindro.Name = "chkCilindro";
            this.chkCilindro.Size = new System.Drawing.Size(87, 24);
            this.chkCilindro.TabIndex = 0;
            this.chkCilindro.Text = "Cilindro";
            this.chkCilindro.UseVisualStyleBackColor = true;
            // 
            // chkTodos
            // 
            this.chkTodos.AutoSize = true;
            this.chkTodos.Location = new System.Drawing.Point(34, 68);
            this.chkTodos.Name = "chkTodos";
            this.chkTodos.Size = new System.Drawing.Size(181, 24);
            this.chkTodos.TabIndex = 10;
            this.chkTodos.Text = "Todos los elementos";
            this.chkTodos.UseVisualStyleBackColor = true;
            // 
            // dgvInventario
            // 
            this.dgvInventario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventario.Location = new System.Drawing.Point(485, 42);
            this.dgvInventario.Name = "dgvInventario";
            this.dgvInventario.RowHeadersWidth = 62;
            this.dgvInventario.RowTemplate.Height = 28;
            this.dgvInventario.Size = new System.Drawing.Size(696, 604);
            this.dgvInventario.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ProyectoFinal1.Properties.Resources.Umbrella_Emblem;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(820, -26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(473, 106);
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1336, 681);
            this.Controls.Add(this.dgvInventario);
            this.Controls.Add(this.grpFiltro);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Consulta de Movimientos";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.grpFiltro.ResumeLayout(false);
            this.grpFiltro.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventario)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpFiltro;
        private System.Windows.Forms.CheckBox chkVaso;
        private System.Windows.Forms.CheckBox chkEspatula;
        private System.Windows.Forms.CheckBox chkTenaza;
        private System.Windows.Forms.CheckBox chkTubo;
        private System.Windows.Forms.CheckBox chkMatraz;
        private System.Windows.Forms.CheckBox chkVidrioReloj;
        private System.Windows.Forms.CheckBox chkEmbudo;
        private System.Windows.Forms.CheckBox chkCilindro;
        private System.Windows.Forms.CheckBox chkTodos;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.DateTimePicker dtpFechaFiltro;
        private System.Windows.Forms.DataGridView dgvInventario;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}