﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoFinal1
{
    internal static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Prepara la base de datos automáticamente (la crea si no existe)
            if (!ConexionBD.InicializarBaseDeDatos())
            {
                MessageBox.Show(
                    "No se encontró ningún SQL Server disponible.\n\n" +
                    "Para solucionarlo instale SQL Server Express LocalDB:\n" +
                    "1. Abra el Instalador de Visual Studio y elija 'Modificar'.\n" +
                    "2. En 'Componentes individuales' busque 'LocalDB'.\n" +
                    "3. Marque 'SQL Server Express LocalDB' y aplique.\n\n" +
                    "Luego vuelva a abrir este programa: la base de datos " +
                    "se creará automáticamente.",
                    "Base de datos no disponible",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Application.Run(new Form1());
        }
    }
}
