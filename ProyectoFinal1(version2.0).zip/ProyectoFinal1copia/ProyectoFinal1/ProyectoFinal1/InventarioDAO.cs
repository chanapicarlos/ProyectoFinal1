﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// integrantes:
// Jeicob Zurita 2-757-811
// Carlos Chanapi 5-718-1429
// Jhony Batista 8-1041-749
// Iker Perez 8-1026-2291
namespace ProyectoFinal1
{
    /// <summary>
    /// Capa de acceso a datos. Encapsula todas las operaciones
    /// contra la base de datos del inventario.
    /// </summary>
    public class InventarioDAO
    {
        /// <summary>
        /// Registra una lista de movimientos dentro de una única transacción.
        /// Si alguno falla, no se guarda ninguno.
        /// </summary>
        public void RegistrarMovimientos(List<Movimiento> movimientos)
        {
            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                conexion.Open();

                using (SqlTransaction transaccion = conexion.BeginTransaction())
                {
                    try
                    {
                        foreach (Movimiento movimiento in movimientos)
                        {
                            GuardarMovimiento(conexion, transaccion, movimiento);
                        }
                        transaccion.Commit();
                    }
                    catch
                    {
                        transaccion.Rollback();  // se deshace todo
                        throw;                   // se propaga al formulario
                    }
                }
            }
        }

        /// <summary>
        /// Inserta un movimiento y actualiza el stock del elemento.
        /// Valida que exista el elemento y que haya stock suficiente.
        /// </summary>
        private void GuardarMovimiento(SqlConnection conexion,
                                       SqlTransaction transaccion,
                                       Movimiento movimiento)
        {
            string sql = @"
                DECLARE @elementoId INT;
                SELECT @elementoId = Id FROM Elementos WHERE Nombre = @nombre;

                IF @elementoId IS NULL
                    THROW 50001, 'El elemento no existe en el catálogo.', 1;

                IF @signo = -1 AND
                   (SELECT StockActual FROM Elementos WHERE Id = @elementoId) < @cantidad
                    THROW 50002, 'No hay stock suficiente para el préstamo.', 1;

                INSERT INTO Movimientos (ElementoId, Tipo, Cantidad, Fecha)
                VALUES (@elementoId, @tipo, @cantidad, @fecha);

                UPDATE Elementos
                SET StockActual = StockActual + (@signo * @cantidad)
                WHERE Id = @elementoId;";

            using (SqlCommand comando = new SqlCommand(sql, conexion, transaccion))
            {
                comando.Parameters.AddWithValue("@nombre", movimiento.NombreElemento);
                comando.Parameters.AddWithValue("@tipo", movimiento.Tipo.ToString());
                comando.Parameters.AddWithValue("@cantidad", movimiento.Cantidad);
                comando.Parameters.AddWithValue("@fecha", movimiento.Fecha);
                comando.Parameters.AddWithValue("@signo", movimiento.ObtenerSigno());
                comando.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Devuelve los movimientos de los elementos indicados en una fecha dada.
        /// </summary>
        public DataTable ConsultarMovimientos(List<string> nombresElementos,
                                              DateTime fecha)
        {
            DataTable tabla = new DataTable();

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                // Se generan parámetros @e0, @e1... para evitar inyección SQL
                List<string> parametros = nombresElementos
                    .Select((nombre, indice) => "@e" + indice)
                    .ToList();

                string sql = $@"
                    SELECT e.Nombre   AS Elemento,
                           m.Tipo     AS Movimiento,
                           m.Cantidad AS Cantidad,
                           m.Fecha    AS Fecha
                    FROM Movimientos m
                    INNER JOIN Elementos e ON e.Id = m.ElementoId
                    WHERE m.Fecha = @fecha
                      AND e.Nombre IN ({string.Join(",", parametros)})
                    ORDER BY e.Nombre, m.Tipo;";

                using (SqlCommand comando = new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue("@fecha", fecha);

                    for (int i = 0; i < nombresElementos.Count; i++)
                    {
                        comando.Parameters.AddWithValue("@e" + i, nombresElementos[i]);
                    }

                    SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                    adaptador.Fill(tabla);   // abre y cierra la conexión sola
                }
            }
            return tabla;
        }

        /// <summary>
        /// Devuelve el stock actual de todos los elementos del catálogo.
        /// </summary>
        public DataTable ConsultarStock()
        {
            DataTable tabla = new DataTable();

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"
                    SELECT Nombre      AS Elemento,
                           StockActual AS [Stock actual]
                    FROM Elementos
                    ORDER BY Nombre;";

                using (SqlCommand comando = new SqlCommand(sql, conexion))
                {
                    SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                    adaptador.Fill(tabla);   // abre y cierra la conexión sola
                }
            }
            return tabla;
        }

        // Stock inicial de cada elemento: si el stock supera este valor,
        // significa que se registraron más entregas que préstamos (anomalía).
        private const int STOCK_MAXIMO = 30;

        /// <summary>
        /// Devuelve los elementos cuyo stock supera el máximo (objetos de más).
        /// La columna Sobrante indica cuántas unidades hay por encima del tope.
        /// </summary>
        public DataTable ConsultarExceso()
        {
            DataTable tabla = new DataTable();

            using (SqlConnection conexion = ConexionBD.ObtenerConexion())
            {
                string sql = @"
                    SELECT Nombre        AS Elemento,
                           StockActual   AS [Stock actual],
                           @maximo       AS [Stock máximo],
                           StockActual - @maximo AS [Sobrante]
                    FROM Elementos
                    WHERE StockActual > @maximo
                    ORDER BY Nombre;";

                using (SqlCommand comando = new SqlCommand(sql, conexion))
                {
                    comando.Parameters.AddWithValue("@maximo", STOCK_MAXIMO);
                    SqlDataAdapter adaptador = new SqlDataAdapter(comando);
                    adaptador.Fill(tabla);   // abre y cierra la conexión sola
                }
            }
            return tabla;
        }

        /// <summary>
        /// Prueba que la conexión con SQL Server funcione.
        /// </summary>
        public bool ProbarConexion()
        {
            try
            {
                using (SqlConnection conexion = ConexionBD.ObtenerConexion())
                {
                    conexion.Open();
                    return true;
                }
            }
            catch (SqlException)
            {
                return false;
            }
        }
    }
}
