﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal1
{
    /// <summary>
    /// Representa un elemento del laboratorio.
    /// </summary>
    public class Elemento
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int StockActual { get; set; }

        public Elemento() { }

        public Elemento(string nombre, int stockActual)
        {
            Nombre = nombre;
            StockActual = stockActual;
        }

        public override string ToString()
        {
            return Nombre;
        }
    }
}
