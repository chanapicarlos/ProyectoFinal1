﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// integrantes:
// Jeicob Zurita 2-757-811
// Carlos Chanapi 5-718-1429
// Jhony Batista 8-1041-749
// Iker Perez 8-1026-2291
namespace ProyectoFinal1
{
    public partial class Form2 : Form
    {
        private readonly InventarioDAO inventarioDAO = new InventarioDAO();

        public Form2()
        {
            InitializeComponent();
        }
        // Evita que los eventos se disparen en cascada al marcar/desmarcar todo
        private bool actualizandoChecks = false;

        private void Form2_Load(object sender, EventArgs e)
        {
            // Solo se puede consultar de la fecha actual hacia atrás
            dtpFechaFiltro.MaxDate = DateTime.Today;
            ConfigurarGrid();
            ConfigurarCheckTodos();
        }

        /// <summary>
        /// Lista con los CheckBox de cada elemento del catálogo.
        /// </summary>
        private List<CheckBox> ObtenerCheckBoxesElementos()
        {
            return new List<CheckBox>
            {
                chkCilindro, chkEmbudo, chkVidrioReloj, chkMatraz,
                chkTubo, chkTenaza, chkEspatula, chkVaso
            };
        }

        /// <summary>
        /// Conecta el CheckBox "Todos los elementos" con los individuales.
        /// </summary>
        private void ConfigurarCheckTodos()
        {
            chkTodos.CheckedChanged += ChkTodos_CheckedChanged;

            foreach (CheckBox chk in ObtenerCheckBoxesElementos())
            {
                chk.CheckedChanged += ElementoIndividual_CheckedChanged;
            }
        }

        /// <summary>
        /// Marcar "Todos" marca los 8 elementos; desmarcarlo los limpia.
        /// </summary>
        private void ChkTodos_CheckedChanged(object sender, EventArgs e)
        {
            if (actualizandoChecks) return;

            actualizandoChecks = true;
            foreach (CheckBox chk in ObtenerCheckBoxesElementos())
            {
                chk.Checked = chkTodos.Checked;
            }
            actualizandoChecks = false;
        }

        /// <summary>
        /// "Todos" queda marcado solo si los 8 elementos lo están.
        /// </summary>
        private void ElementoIndividual_CheckedChanged(object sender, EventArgs e)
        {
            if (actualizandoChecks) return;

            actualizandoChecks = true;
            chkTodos.Checked = ObtenerCheckBoxesElementos().All(chk => chk.Checked);
            actualizandoChecks = false;
        }

        /// <summary>
        /// Ajustes visuales del DataGridView.
        /// </summary>
        private void ConfigurarGrid()
        {
            dgvInventario.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvInventario.ReadOnly = true;
            dgvInventario.AllowUserToAddRows = false;
            dgvInventario.AllowUserToDeleteRows = false;
            dgvInventario.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvInventario.MultiSelect = false;
        }
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            List<string> seleccionados = ObtenerElementosSeleccionados();

            if (seleccionados.Count == 0)
            {
                MessageBox.Show("Debe seleccionar al menos un elemento.",
                    "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                DataTable resultado = inventarioDAO.ConsultarMovimientos(
                    seleccionados, dtpFechaFiltro.Value.Date);

                dgvInventario.DataSource = resultado;

                if (resultado.Rows.Count == 0)
                {
                    MessageBox.Show("No hay movimientos registrados en esa fecha.",
                        "Sin resultados", MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Error en la base de datos: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inesperado: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
            /// <summary>
            /// Recoge los nombres de los elementos marcados con CheckBox.
            /// </summary>
        private List<string> ObtenerElementosSeleccionados()
        {
            List<string> seleccionados = new List<string>();

            if (chkCilindro.Checked) seleccionados.Add("Cilindro graduado de 100mL");
            if (chkEmbudo.Checked) seleccionados.Add("Embudo corriente");
            if (chkVidrioReloj.Checked) seleccionados.Add("Vidrio reloj");
            if (chkMatraz.Checked) seleccionados.Add("Matraz erlenmeyer");
            if (chkTubo.Checked) seleccionados.Add("Tubo de ensayo");
            if (chkTenaza.Checked) seleccionados.Add("Tenaza de metal");
            if (chkEspatula.Checked) seleccionados.Add("Espátula de metal");
            if (chkVaso.Checked) seleccionados.Add("Vaso químico");

            return seleccionados;
        }
    }
    
}
