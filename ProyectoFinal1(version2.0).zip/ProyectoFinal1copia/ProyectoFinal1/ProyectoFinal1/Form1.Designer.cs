﻿namespace ProyectoFinal1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabMovimientos = new System.Windows.Forms.TabControl();
            this.tabPrestamo = new System.Windows.Forms.TabPage();
            this.dtpFechaPrestamo = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTenazaPrestamo = new System.Windows.Forms.TextBox();
            this.btnGuardarPrestamo = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtCilindroPrestamo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtVasoPrestamo = new System.Windows.Forms.TextBox();
            this.txtEmbudoPrestamo = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtEspatulaPrestamo = new System.Windows.Forms.TextBox();
            this.txtVidrioRelojPrestamo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMatrazPrestamo = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTuboPrestamo = new System.Windows.Forms.TextBox();
            this.tabEntrega = new System.Windows.Forms.TabPage();
            this.dtpFechaEntrega = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTenazaEntrega = new System.Windows.Forms.TextBox();
            this.btnGuardarEntrega = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtCilindroEntrega = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtVasoEntrega = new System.Windows.Forms.TextBox();
            this.txtEmbudoEntrega = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtEspatulaEntrega = new System.Windows.Forms.TextBox();
            this.txtVidrioRelojEntrega = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtMatrazEntrega = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtTuboEntrega = new System.Windows.Forms.TextBox();
            this.tabStock = new System.Windows.Forms.TabPage();
            this.dgvStock = new System.Windows.Forms.DataGridView();
            this.tabExceso = new System.Windows.Forms.TabPage();
            this.dgvExceso = new System.Windows.Forms.DataGridView();
            this.btnAbrirConsulta = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.tabMovimientos.SuspendLayout();
            this.tabPrestamo.SuspendLayout();
            this.tabEntrega.SuspendLayout();
            this.tabStock.SuspendLayout();
            this.tabExceso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExceso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabMovimientos
            // 
            this.tabMovimientos.Controls.Add(this.tabPrestamo);
            this.tabMovimientos.Controls.Add(this.tabEntrega);
            this.tabMovimientos.Controls.Add(this.tabStock);
            this.tabMovimientos.Controls.Add(this.tabExceso);
            this.tabMovimientos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabMovimientos.Location = new System.Drawing.Point(12, 50);
            this.tabMovimientos.Name = "tabMovimientos";
            this.tabMovimientos.SelectedIndex = 0;
            this.tabMovimientos.Size = new System.Drawing.Size(950, 569);
            this.tabMovimientos.TabIndex = 0;
            this.tabMovimientos.SelectedIndexChanged += new System.EventHandler(this.tabMovimientos_SelectedIndexChanged);
            // 
            // tabPrestamo
            // 
            this.tabPrestamo.Controls.Add(this.dtpFechaPrestamo);
            this.tabPrestamo.Controls.Add(this.label9);
            this.tabPrestamo.Controls.Add(this.txtTenazaPrestamo);
            this.tabPrestamo.Controls.Add(this.btnGuardarPrestamo);
            this.tabPrestamo.Controls.Add(this.label8);
            this.tabPrestamo.Controls.Add(this.txtCilindroPrestamo);
            this.tabPrestamo.Controls.Add(this.label7);
            this.tabPrestamo.Controls.Add(this.txtVasoPrestamo);
            this.tabPrestamo.Controls.Add(this.txtEmbudoPrestamo);
            this.tabPrestamo.Controls.Add(this.label1);
            this.tabPrestamo.Controls.Add(this.label6);
            this.tabPrestamo.Controls.Add(this.txtEspatulaPrestamo);
            this.tabPrestamo.Controls.Add(this.txtVidrioRelojPrestamo);
            this.tabPrestamo.Controls.Add(this.label2);
            this.tabPrestamo.Controls.Add(this.label5);
            this.tabPrestamo.Controls.Add(this.txtMatrazPrestamo);
            this.tabPrestamo.Controls.Add(this.label3);
            this.tabPrestamo.Controls.Add(this.label4);
            this.tabPrestamo.Controls.Add(this.txtTuboPrestamo);
            this.tabPrestamo.Location = new System.Drawing.Point(4, 29);
            this.tabPrestamo.Name = "tabPrestamo";
            this.tabPrestamo.Padding = new System.Windows.Forms.Padding(3);
            this.tabPrestamo.Size = new System.Drawing.Size(942, 536);
            this.tabPrestamo.TabIndex = 0;
            this.tabPrestamo.Text = "Prestamo";
            this.tabPrestamo.UseVisualStyleBackColor = true;
            // 
            // dtpFechaPrestamo
            // 
            this.dtpFechaPrestamo.Location = new System.Drawing.Point(97, 367);
            this.dtpFechaPrestamo.Name = "dtpFechaPrestamo";
            this.dtpFechaPrestamo.Size = new System.Drawing.Size(315, 26);
            this.dtpFechaPrestamo.TabIndex = 21;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(42, 367);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 20);
            this.label9.TabIndex = 20;
            this.label9.Text = "fecha";
            // 
            // txtTenazaPrestamo
            // 
            this.txtTenazaPrestamo.Location = new System.Drawing.Point(279, 222);
            this.txtTenazaPrestamo.MaxLength = 2;
            this.txtTenazaPrestamo.Name = "txtTenazaPrestamo";
            this.txtTenazaPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtTenazaPrestamo.TabIndex = 13;
            // 
            // btnGuardarPrestamo
            // 
            this.btnGuardarPrestamo.Location = new System.Drawing.Point(46, 442);
            this.btnGuardarPrestamo.Name = "btnGuardarPrestamo";
            this.btnGuardarPrestamo.Size = new System.Drawing.Size(151, 48);
            this.btnGuardarPrestamo.TabIndex = 18;
            this.btnGuardarPrestamo.Text = "Guardar Prestamo";
            this.btnGuardarPrestamo.UseVisualStyleBackColor = true;
            this.btnGuardarPrestamo.Click += new System.EventHandler(this.btnGuardarPrestamo_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 304);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 20);
            this.label8.TabIndex = 7;
            this.label8.Text = "vaso quimico";
            // 
            // txtCilindroPrestamo
            // 
            this.txtCilindroPrestamo.Location = new System.Drawing.Point(279, 23);
            this.txtCilindroPrestamo.MaxLength = 2;
            this.txtCilindroPrestamo.Name = "txtCilindroPrestamo";
            this.txtCilindroPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtCilindroPrestamo.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(152, 20);
            this.label7.TabIndex = 6;
            this.label7.Text = "espatula de metal";
            // 
            // txtVasoPrestamo
            // 
            this.txtVasoPrestamo.Location = new System.Drawing.Point(278, 305);
            this.txtVasoPrestamo.MaxLength = 2;
            this.txtVasoPrestamo.Name = "txtVasoPrestamo";
            this.txtVasoPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtVasoPrestamo.TabIndex = 15;
            // 
            // txtEmbudoPrestamo
            // 
            this.txtEmbudoPrestamo.Location = new System.Drawing.Point(278, 68);
            this.txtEmbudoPrestamo.MaxLength = 2;
            this.txtEmbudoPrestamo.Name = "txtEmbudoPrestamo";
            this.txtEmbudoPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtEmbudoPrestamo.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "cilindro graduadu de 100mL";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 221);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 20);
            this.label6.TabIndex = 5;
            this.label6.Text = "tenaza de metal";
            // 
            // txtEspatulaPrestamo
            // 
            this.txtEspatulaPrestamo.Location = new System.Drawing.Point(278, 261);
            this.txtEspatulaPrestamo.MaxLength = 2;
            this.txtEspatulaPrestamo.Name = "txtEspatulaPrestamo";
            this.txtEspatulaPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtEspatulaPrestamo.TabIndex = 14;
            // 
            // txtVidrioRelojPrestamo
            // 
            this.txtVidrioRelojPrestamo.Location = new System.Drawing.Point(278, 108);
            this.txtVidrioRelojPrestamo.MaxLength = 2;
            this.txtVidrioRelojPrestamo.Name = "txtVidrioRelojPrestamo";
            this.txtVidrioRelojPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtVidrioRelojPrestamo.TabIndex = 10;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "embudo corrinte";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 182);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "tubo de ensayo";
            // 
            // txtMatrazPrestamo
            // 
            this.txtMatrazPrestamo.Location = new System.Drawing.Point(279, 144);
            this.txtMatrazPrestamo.MaxLength = 2;
            this.txtMatrazPrestamo.Name = "txtMatrazPrestamo";
            this.txtMatrazPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtMatrazPrestamo.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "vidrio reloj";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(157, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "matraz erlenmeyer";
            // 
            // txtTuboPrestamo
            // 
            this.txtTuboPrestamo.Location = new System.Drawing.Point(278, 183);
            this.txtTuboPrestamo.MaxLength = 2;
            this.txtTuboPrestamo.Name = "txtTuboPrestamo";
            this.txtTuboPrestamo.Size = new System.Drawing.Size(290, 26);
            this.txtTuboPrestamo.TabIndex = 12;
            // 
            // tabEntrega
            // 
            this.tabEntrega.Controls.Add(this.dtpFechaEntrega);
            this.tabEntrega.Controls.Add(this.label10);
            this.tabEntrega.Controls.Add(this.txtTenazaEntrega);
            this.tabEntrega.Controls.Add(this.btnGuardarEntrega);
            this.tabEntrega.Controls.Add(this.label11);
            this.tabEntrega.Controls.Add(this.txtCilindroEntrega);
            this.tabEntrega.Controls.Add(this.label12);
            this.tabEntrega.Controls.Add(this.txtVasoEntrega);
            this.tabEntrega.Controls.Add(this.txtEmbudoEntrega);
            this.tabEntrega.Controls.Add(this.label13);
            this.tabEntrega.Controls.Add(this.label14);
            this.tabEntrega.Controls.Add(this.txtEspatulaEntrega);
            this.tabEntrega.Controls.Add(this.txtVidrioRelojEntrega);
            this.tabEntrega.Controls.Add(this.label15);
            this.tabEntrega.Controls.Add(this.label16);
            this.tabEntrega.Controls.Add(this.txtMatrazEntrega);
            this.tabEntrega.Controls.Add(this.label17);
            this.tabEntrega.Controls.Add(this.label18);
            this.tabEntrega.Controls.Add(this.txtTuboEntrega);
            this.tabEntrega.Location = new System.Drawing.Point(4, 29);
            this.tabEntrega.Name = "tabEntrega";
            this.tabEntrega.Padding = new System.Windows.Forms.Padding(3);
            this.tabEntrega.Size = new System.Drawing.Size(942, 536);
            this.tabEntrega.TabIndex = 1;
            this.tabEntrega.Text = "Entrega";
            this.tabEntrega.UseVisualStyleBackColor = true;
            // 
            // dtpFechaEntrega
            // 
            this.dtpFechaEntrega.Location = new System.Drawing.Point(87, 369);
            this.dtpFechaEntrega.Name = "dtpFechaEntrega";
            this.dtpFechaEntrega.Size = new System.Drawing.Size(315, 26);
            this.dtpFechaEntrega.TabIndex = 40;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(32, 369);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(54, 20);
            this.label10.TabIndex = 39;
            this.label10.Text = "fecha";
            // 
            // txtTenazaEntrega
            // 
            this.txtTenazaEntrega.Location = new System.Drawing.Point(269, 224);
            this.txtTenazaEntrega.MaxLength = 2;
            this.txtTenazaEntrega.Name = "txtTenazaEntrega";
            this.txtTenazaEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtTenazaEntrega.TabIndex = 35;
            // 
            // btnGuardarEntrega
            // 
            this.btnGuardarEntrega.Location = new System.Drawing.Point(36, 444);
            this.btnGuardarEntrega.Name = "btnGuardarEntrega";
            this.btnGuardarEntrega.Size = new System.Drawing.Size(151, 48);
            this.btnGuardarEntrega.TabIndex = 38;
            this.btnGuardarEntrega.Text = "Guardar Entrega";
            this.btnGuardarEntrega.UseVisualStyleBackColor = true;
            this.btnGuardarEntrega.Click += new System.EventHandler(this.btnGuardarEntrega_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(32, 306);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(112, 20);
            this.label11.TabIndex = 29;
            this.label11.Text = "vaso quimico";
            // 
            // txtCilindroEntrega
            // 
            this.txtCilindroEntrega.Location = new System.Drawing.Point(269, 25);
            this.txtCilindroEntrega.MaxLength = 2;
            this.txtCilindroEntrega.Name = "txtCilindroEntrega";
            this.txtCilindroEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtCilindroEntrega.TabIndex = 30;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(32, 262);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(152, 20);
            this.label12.TabIndex = 28;
            this.label12.Text = "espatula de metal";
            // 
            // txtVasoEntrega
            // 
            this.txtVasoEntrega.Location = new System.Drawing.Point(268, 307);
            this.txtVasoEntrega.MaxLength = 2;
            this.txtVasoEntrega.Name = "txtVasoEntrega";
            this.txtVasoEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtVasoEntrega.TabIndex = 37;
            // 
            // txtEmbudoEntrega
            // 
            this.txtEmbudoEntrega.Location = new System.Drawing.Point(268, 70);
            this.txtEmbudoEntrega.MaxLength = 2;
            this.txtEmbudoEntrega.Name = "txtEmbudoEntrega";
            this.txtEmbudoEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtEmbudoEntrega.TabIndex = 31;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(32, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(231, 20);
            this.label13.TabIndex = 22;
            this.label13.Text = "cilindro graduadu de 100mL";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(32, 223);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(138, 20);
            this.label14.TabIndex = 27;
            this.label14.Text = "tenaza de metal";
            // 
            // txtEspatulaEntrega
            // 
            this.txtEspatulaEntrega.Location = new System.Drawing.Point(268, 263);
            this.txtEspatulaEntrega.MaxLength = 2;
            this.txtEspatulaEntrega.Name = "txtEspatulaEntrega";
            this.txtEspatulaEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtEspatulaEntrega.TabIndex = 36;
            // 
            // txtVidrioRelojEntrega
            // 
            this.txtVidrioRelojEntrega.Location = new System.Drawing.Point(268, 110);
            this.txtVidrioRelojEntrega.MaxLength = 2;
            this.txtVidrioRelojEntrega.Name = "txtVidrioRelojEntrega";
            this.txtVidrioRelojEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtVidrioRelojEntrega.TabIndex = 32;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(32, 66);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(139, 20);
            this.label15.TabIndex = 23;
            this.label15.Text = "embudo corrinte";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(32, 184);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(132, 20);
            this.label16.TabIndex = 26;
            this.label16.Text = "tubo de ensayo";
            // 
            // txtMatrazEntrega
            // 
            this.txtMatrazEntrega.Location = new System.Drawing.Point(269, 146);
            this.txtMatrazEntrega.MaxLength = 2;
            this.txtMatrazEntrega.Name = "txtMatrazEntrega";
            this.txtMatrazEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtMatrazEntrega.TabIndex = 33;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(32, 106);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(90, 20);
            this.label17.TabIndex = 24;
            this.label17.Text = "vidrio reloj";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(32, 145);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(157, 20);
            this.label18.TabIndex = 25;
            this.label18.Text = "matraz erlenmeyer";
            // 
            // txtTuboEntrega
            // 
            this.txtTuboEntrega.Location = new System.Drawing.Point(268, 185);
            this.txtTuboEntrega.MaxLength = 2;
            this.txtTuboEntrega.Name = "txtTuboEntrega";
            this.txtTuboEntrega.Size = new System.Drawing.Size(290, 26);
            this.txtTuboEntrega.TabIndex = 34;
            // 
            // tabStock
            // 
            this.tabStock.Controls.Add(this.dgvStock);
            this.tabStock.Location = new System.Drawing.Point(4, 29);
            this.tabStock.Name = "tabStock";
            this.tabStock.Padding = new System.Windows.Forms.Padding(3);
            this.tabStock.Size = new System.Drawing.Size(942, 536);
            this.tabStock.TabIndex = 2;
            this.tabStock.Text = "Stock";
            this.tabStock.UseVisualStyleBackColor = true;
            // 
            // dgvStock
            // 
            this.dgvStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStock.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvStock.Location = new System.Drawing.Point(3, 3);
            this.dgvStock.Name = "dgvStock";
            this.dgvStock.RowHeadersWidth = 62;
            this.dgvStock.RowTemplate.Height = 28;
            this.dgvStock.Size = new System.Drawing.Size(936, 530);
            this.dgvStock.TabIndex = 0;
            //
            // tabExceso
            //
            this.tabExceso.Controls.Add(this.dgvExceso);
            this.tabExceso.Location = new System.Drawing.Point(4, 29);
            this.tabExceso.Name = "tabExceso";
            this.tabExceso.Padding = new System.Windows.Forms.Padding(3);
            this.tabExceso.Size = new System.Drawing.Size(942, 536);
            this.tabExceso.TabIndex = 3;
            this.tabExceso.Text = "Excedente";
            this.tabExceso.UseVisualStyleBackColor = true;
            //
            // dgvExceso
            //
            this.dgvExceso.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvExceso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvExceso.Location = new System.Drawing.Point(3, 3);
            this.dgvExceso.Name = "dgvExceso";
            this.dgvExceso.RowHeadersWidth = 62;
            this.dgvExceso.RowTemplate.Height = 28;
            this.dgvExceso.Size = new System.Drawing.Size(936, 530);
            this.dgvExceso.TabIndex = 0;
            //
            // btnAbrirConsulta
            //
            this.btnAbrirConsulta.Location = new System.Drawing.Point(352, 635);
            this.btnAbrirConsulta.Name = "btnAbrirConsulta";
            this.btnAbrirConsulta.Size = new System.Drawing.Size(328, 54);
            this.btnAbrirConsulta.TabIndex = 1;
            this.btnAbrirConsulta.Text = "Abrir Consulta ";
            this.btnAbrirConsulta.UseVisualStyleBackColor = true;
            this.btnAbrirConsulta.Click += new System.EventHandler(this.btnAbrirConsulta_Click_1);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::ProyectoFinal1.Properties.Resources.Umbrella_Emblem;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(602, -26);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(473, 106);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 701);
            this.Controls.Add(this.btnAbrirConsulta);
            this.Controls.Add(this.tabMovimientos);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Gestión de Inventario — Laboratorio";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabMovimientos.ResumeLayout(false);
            this.tabPrestamo.ResumeLayout(false);
            this.tabPrestamo.PerformLayout();
            this.tabEntrega.ResumeLayout(false);
            this.tabEntrega.PerformLayout();
            this.tabStock.ResumeLayout(false);
            this.tabExceso.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvStock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExceso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabMovimientos;
        private System.Windows.Forms.TabPage tabPrestamo;
        private System.Windows.Forms.TabPage tabEntrega;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtTenazaPrestamo;
        private System.Windows.Forms.Button btnGuardarPrestamo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtCilindroPrestamo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtVasoPrestamo;
        private System.Windows.Forms.TextBox txtEmbudoPrestamo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtEspatulaPrestamo;
        private System.Windows.Forms.TextBox txtVidrioRelojPrestamo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMatrazPrestamo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTuboPrestamo;
        private System.Windows.Forms.DateTimePicker dtpFechaPrestamo;
        private System.Windows.Forms.DateTimePicker dtpFechaEntrega;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTenazaEntrega;
        private System.Windows.Forms.Button btnGuardarEntrega;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtCilindroEntrega;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtVasoEntrega;
        private System.Windows.Forms.TextBox txtEmbudoEntrega;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtEspatulaEntrega;
        private System.Windows.Forms.TextBox txtVidrioRelojEntrega;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtMatrazEntrega;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtTuboEntrega;
        private System.Windows.Forms.Button btnAbrirConsulta;
        private System.Windows.Forms.TabPage tabStock;
        private System.Windows.Forms.DataGridView dgvStock;
        private System.Windows.Forms.TabPage tabExceso;
        private System.Windows.Forms.DataGridView dgvExceso;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

