﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
// integrantes:
// Jeicob Zurita 2-757-811
// Carlos Chanapi 5-718-1429
// Jhony Batista 8-1041-749
// Iker Perez 8-1026-2291
namespace ProyectoFinal1
{
    public partial class Form1 : Form
    {
        private readonly InventarioDAO inventarioDAO = new InventarioDAO();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // Los préstamos y entregas solo se pueden registrar con la fecha actual
            dtpFechaPrestamo.MinDate = DateTime.Today;
            dtpFechaPrestamo.MaxDate = DateTime.Today;
            dtpFechaEntrega.MinDate = DateTime.Today;
            dtpFechaEntrega.MaxDate = DateTime.Today;

            if (!inventarioDAO.ProbarConexion())
            {
                MessageBox.Show("No se pudo conectar con la base de datos.",
                    "Error de conexión", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            ConfigurarGrid(dgvStock);
            ConfigurarGrid(dgvExceso);
            CargarStock();
            CargarExceso();
        }

        /// <summary>
        /// Ajustes visuales comunes de un DataGridView de solo lectura.
        /// </summary>
        private void ConfigurarGrid(DataGridView grid)
        {
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
        }

        /// <summary>
        /// Carga el stock actual de cada elemento en la pestaña Stock.
        /// </summary>
        private void CargarStock()
        {
            try
            {
                dgvStock.DataSource = inventarioDAO.ConsultarStock();
            }
            catch (Exception ex)
            {
                // Cualquier fallo (SQL o de otro tipo) se informa sin cerrar la app
                MessageBox.Show("Error al cargar el stock: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Carga los elementos con stock por encima del máximo (objetos de más).
        /// </summary>
        private void CargarExceso()
        {
            try
            {
                dgvExceso.DataSource = inventarioDAO.ConsultarExceso();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar el excedente: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Refresca los datos cada vez que el usuario entra a Stock o Excedente.
        /// </summary>
        private void tabMovimientos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabMovimientos.SelectedTab == tabStock)
            {
                CargarStock();
            }
            else if (tabMovimientos.SelectedTab == tabExceso)
            {
                CargarExceso();
            }
        }

        private void btnGuardarPrestamo_Click(object sender, EventArgs e)
        {
            Dictionary<string, TextBox> campos = new Dictionary<string, TextBox>
            {
                { "Cilindro graduado de 100mL", txtCilindroPrestamo },
                { "Embudo corriente",           txtEmbudoPrestamo },
                { "Vidrio reloj",               txtVidrioRelojPrestamo },
                { "Matraz erlenmeyer",          txtMatrazPrestamo },
                { "Tubo de ensayo",             txtTuboPrestamo },
                { "Tenaza de metal",            txtTenazaPrestamo },
                { "Espátula de metal",          txtEspatulaPrestamo },
                { "Vaso químico",               txtVasoPrestamo }
            };

            ProcesarMovimiento(TipoMovimiento.Prestamo, campos,
                               dtpFechaPrestamo.Value.Date);
        }

        private void btnGuardarEntrega_Click(object sender, EventArgs e)
        {
            Dictionary<string, TextBox> campos = new Dictionary<string, TextBox>
            {
                { "Cilindro graduado de 100mL", txtCilindroEntrega },
                { "Embudo corriente",           txtEmbudoEntrega },
                { "Vidrio reloj",               txtVidrioRelojEntrega },
                { "Matraz erlenmeyer",          txtMatrazEntrega },
                { "Tubo de ensayo",             txtTuboEntrega },
                { "Tenaza de metal",            txtTenazaEntrega },
                { "Espátula de metal",          txtEspatulaEntrega },
                { "Vaso químico",               txtVasoEntrega }
            };

            ProcesarMovimiento(TipoMovimiento.Entrega, campos,
                               dtpFechaEntrega.Value.Date);
        }
        /// <summary>
        /// Valida las entradas y delega el guardado a la capa de datos.
        /// </summary>
        private void ProcesarMovimiento(TipoMovimiento tipo,
                                        Dictionary<string, TextBox> campos,
                                        DateTime fecha)
        {
            // Doble validación: aunque el calendario está limitado al día
            // actual, se comprueba de nuevo al guardar (cubre el caso de
            // dejar el programa abierto pasada la medianoche).
            if (fecha != DateTime.Today)
            {
                MessageBox.Show(
                    "Los movimientos solo se pueden registrar con la fecha de hoy.\n" +
                    "Cierre y vuelva a abrir el programa para actualizar la fecha.",
                    "Fecha no válida", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            List<Movimiento> movimientos = ValidarCampos(tipo, campos, fecha);
            if (movimientos == null) return;   // hubo error de validación

            if (movimientos.Count == 0)
            {
                MessageBox.Show("Debe ingresar al menos una cantidad.",
                    "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                inventarioDAO.RegistrarMovimientos(movimientos);
                MessageBox.Show($"{tipo} registrada correctamente.",
                    "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LimpiarCampos(campos);
                CargarStock();    // la pestaña Stock queda al día
                CargarExceso();   // y la de Excedente detecta anomalías nuevas
            }
            catch (SqlException ex)
            {
                // Errores lanzados con THROW desde SQL Server
                MessageBox.Show("Error en la base de datos: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inesperado: " + ex.Message,
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Valida cada TextBox. Devuelve null si alguno es inválido.
        /// Los campos vacíos se ignoran.
        /// </summary>
        private List<Movimiento> ValidarCampos(TipoMovimiento tipo,
                                               Dictionary<string, TextBox> campos,
                                               DateTime fecha)
        {
            List<Movimiento> movimientos = new List<Movimiento>();

            foreach (KeyValuePair<string, TextBox> campo in campos)
            {
                string texto = campo.Value.Text.Trim();

                if (string.IsNullOrEmpty(texto)) continue;

                if (!int.TryParse(texto, out int cantidad))
                {
                    MessageBox.Show($"La cantidad de '{campo.Key}' debe ser un número entero.",
                        "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    campo.Value.Focus();
                    campo.Value.SelectAll();
                    return null;
                }

                if (cantidad < 0)
                {
                    MessageBox.Show($"La cantidad de '{campo.Key}' no puede ser negativa.",
                        "Validación", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    campo.Value.Focus();
                    return null;
                }

                if (cantidad > 0)
                {
                    movimientos.Add(new Movimiento(campo.Key, tipo, cantidad, fecha));
                }
            }
            return movimientos;
        }

        private void LimpiarCampos(Dictionary<string, TextBox> campos)
        {
            foreach (KeyValuePair<string, TextBox> campo in campos)
            {
                campo.Value.Clear();
            }
        }

       

        private void btnAbrirConsulta_Click_1(object sender, EventArgs e)
        {
            using (Form2 formularioConsulta = new Form2())
            {
                formularioConsulta.ShowDialog();
            }
        }
    }
}
