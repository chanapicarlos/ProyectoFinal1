using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// integrantes:
// Jeicob Zurita 2-757-811
// Carlos Chanapi 5-718-1429
// Jhony Batista 8-1041-749
// Iker Perez 8-1026-2291
namespace ProyectoFinal1
{
    /// <summary>
    /// Centraliza la cadena de conexión, la creación de conexiones y la
    /// preparación automática de la base de datos al iniciar la aplicación.
    /// </summary>
    public class ConexionBD
    {
        // Constantes en SNAKE_CASE según las convenciones del proyecto
        private const string NOMBRE_BD = "InventarioLab";

        // Servidores que se prueban en orden hasta encontrar uno disponible
        private static readonly string[] SERVIDORES_CANDIDATOS =
        {
            @"(localdb)\MSSQLLocalDB",
            @"localhost",
            @".\SQLEXPRESS"
        };

        private static string servidorActivo = SERVIDORES_CANDIDATOS[0];

        /// <summary>
        /// Devuelve una nueva conexión sin abrir.
        /// </summary>
        public static SqlConnection ObtenerConexion()
        {
            return new SqlConnection(ConstruirCadena(servidorActivo, NOMBRE_BD));
        }

        private static string ConstruirCadena(string servidor, string baseDatos,
                                              int segundosEspera = 5)
        {
            return $"Server={servidor};Database={baseDatos};" +
                   $"Integrated Security=True;Connect Timeout={segundosEspera};";
        }

        /// <summary>
        /// Busca un SQL Server disponible y garantiza que la base de datos
        /// exista con sus tablas, catálogo y movimientos históricos.
        /// Devuelve false si no se encontró ningún servidor.
        /// </summary>
        public static bool InicializarBaseDeDatos()
        {
            // Dos pasadas: la primera es rápida (5 s) para no demorar el
            // arranque normal; si LocalDB estaba dormido, ese intento lo
            // despierta y la segunda pasada espera con paciencia (20 s).
            for (int intento = 0; intento < 2; intento++)
            {
                int segundosEspera = intento == 0 ? 5 : 20;

                foreach (string servidor in SERVIDORES_CANDIDATOS)
                {
                    try
                    {
                        using (SqlConnection conexionMaster =
                            new SqlConnection(ConstruirCadena(servidor, "master", segundosEspera)))
                        {
                            conexionMaster.Open();
                            servidorActivo = servidor;
                            CrearBaseDeDatosSiFalta(conexionMaster);
                        }

                        using (SqlConnection conexion = ObtenerConexion())
                        {
                            conexion.Open();
                            CrearTablasYDatosSiFaltan(conexion);
                        }
                        return true;
                    }
                    catch (SqlException)
                    {
                        // Este servidor no está disponible: se prueba el siguiente
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Crea la base de datos si no está registrada en el servidor.
        /// Si quedaron archivos .mdf de una ejecución anterior, los adjunta.
        /// </summary>
        private static void CrearBaseDeDatosSiFalta(SqlConnection conexionMaster)
        {
            try
            {
                EjecutarComando(conexionMaster,
                    $"IF DB_ID(N'{NOMBRE_BD}') IS NULL CREATE DATABASE [{NOMBRE_BD}];");
            }
            catch (SqlException)
            {
                // El CREATE falló, normalmente porque los archivos ya existen
                // en el disco: se vuelven a adjuntar.
                string rutaDatos;
                using (SqlCommand comando = new SqlCommand(
                    "SELECT CONVERT(NVARCHAR(500), " +
                    "SERVERPROPERTY('InstanceDefaultDataPath'))", conexionMaster))
                {
                    rutaDatos = (string)comando.ExecuteScalar();
                }

                EjecutarComando(conexionMaster, $@"
                    CREATE DATABASE [{NOMBRE_BD}]
                    ON (FILENAME = N'{rutaDatos}{NOMBRE_BD}.mdf'),
                       (FILENAME = N'{rutaDatos}{NOMBRE_BD}_log.ldf')
                    FOR ATTACH;");
            }
        }

        /// <summary>
        /// Crea las tablas, el catálogo de elementos y los movimientos
        /// históricos (del 1 de enero hasta ayer) si aún no existen.
        /// </summary>
        private static void CrearTablasYDatosSiFaltan(SqlConnection conexion)
        {
            EjecutarComando(conexion, @"
                IF OBJECT_ID(N'dbo.Elementos', N'U') IS NULL
                    CREATE TABLE dbo.Elementos (
                        Id          INT IDENTITY(1,1) PRIMARY KEY,
                        Nombre      NVARCHAR(100) NOT NULL UNIQUE,
                        StockActual INT NOT NULL DEFAULT 0
                    );

                IF OBJECT_ID(N'dbo.Movimientos', N'U') IS NULL
                    CREATE TABLE dbo.Movimientos (
                        Id         INT IDENTITY(1,1) PRIMARY KEY,
                        ElementoId INT NOT NULL
                                   FOREIGN KEY REFERENCES dbo.Elementos(Id),
                        Tipo       NVARCHAR(20) NOT NULL,
                        Cantidad   INT NOT NULL,
                        Fecha      DATE NOT NULL
                    );

                IF NOT EXISTS (SELECT 1 FROM dbo.Elementos)
                    INSERT INTO dbo.Elementos (Nombre, StockActual) VALUES
                        (N'Cilindro graduado de 100mL', 30),
                        (N'Embudo corriente',           30),
                        (N'Vidrio reloj',               30),
                        (N'Matraz erlenmeyer',          30),
                        (N'Tubo de ensayo',             30),
                        (N'Tenaza de metal',            30),
                        (N'Espátula de metal',          30),
                        (N'Vaso químico',               30);

                -- Movimientos históricos del 1 de enero hasta ayer
                IF NOT EXISTS (SELECT 1 FROM dbo.Movimientos
                               WHERE Fecha < CAST(GETDATE() AS DATE))
                BEGIN
                    DECLARE @hoy DATE = CAST(GETDATE() AS DATE);
                    DECLARE @id INT = 1;

                    WHILE @id <= 8
                    BEGIN
                        DECLARE @fecha DATE = DATEADD(DAY, @id,
                            DATEFROMPARTS(YEAR(@hoy), 1, 1));
                        DECLARE @paso INT = 6 + @id;

                        WHILE @fecha < @hoy
                        BEGIN
                            DECLARE @cant INT =
                                1 + (@id + DATEPART(DAYOFYEAR, @fecha)) % 4;

                            INSERT INTO dbo.Movimientos
                                (ElementoId, Tipo, Cantidad, Fecha)
                            VALUES (@id, N'Prestamo', @cant, @fecha);

                            DECLARE @fechaDev DATE = DATEADD(DAY, 3, @fecha);
                            IF @fechaDev < @hoy
                                INSERT INTO dbo.Movimientos
                                    (ElementoId, Tipo, Cantidad, Fecha)
                                VALUES (@id, N'Entrega', @cant, @fechaDev);

                            SET @fecha = DATEADD(DAY, @paso, @fecha);
                        END
                        SET @id = @id + 1;
                    END

                    -- Recalcula el stock: 30 inicial + entregas - préstamos
                    UPDATE e
                    SET StockActual = 30 + ISNULL(s.Total, 0)
                    FROM dbo.Elementos e
                    LEFT JOIN (
                        SELECT ElementoId,
                               SUM(CASE WHEN Tipo = N'Entrega'
                                        THEN Cantidad ELSE -Cantidad END) AS Total
                        FROM dbo.Movimientos
                        GROUP BY ElementoId
                    ) s ON s.ElementoId = e.Id;
                END");
        }

        private static void EjecutarComando(SqlConnection conexion, string sql)
        {
            using (SqlCommand comando = new SqlCommand(sql, conexion))
            {
                comando.ExecuteNonQuery();
            }
        }
    }
}
