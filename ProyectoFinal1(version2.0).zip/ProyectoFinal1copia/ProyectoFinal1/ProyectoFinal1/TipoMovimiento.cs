﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal1
{
    /// <summary>
    /// Tipos de movimiento del inventario.
    /// Prestamo resta stock, Entrega lo suma.
    /// </summary>
    public enum TipoMovimiento
    {
        Prestamo,
        Entrega
    }
}
